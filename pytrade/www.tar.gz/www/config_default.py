configs = {
	'debug' : True,
	'db' : {
		'host' : 'localhost',
		'port' : 3306,
		'user' : 'pytrade',
		'password' : '131413',
		'db' : 'myblog'
	},
	'server' : {
		'host' : '121.42.193.169',
		'port' : 9999
	},
	'session' : {
		'secret' : 'pytrade'
	}
}