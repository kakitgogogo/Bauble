configs = {
	'server' : {
		'port' : 9999
	}
}